"""Measurable localization-trust criterion for X2 motion (pure numpy, no ROS imports; tested without a robot).

Why: map->odom being fresh only says AMCL is still publishing. AMCL republishes its last transform forever, also
after it locked onto a symmetric / degenerate place (one straight wall slides along the wall; the 52 degree lidar
sector sees a single wall) or after a wrong seed. Motion may only run while ALL of these hold:

  T1 freshness     map->odom, amcl_pose and particle_cloud (while moving), scan are recent. AMCL publishes
                   amcl_pose / particle_cloud only on a filter update (i.e. after motion), so while standing its
                   liveness is the map->odom TF it re-sends for every scan (T1_tf_stale). T1_tf_frozen: the
                   odom->base_footprint TF keeps identical content (fresh stamps) while the odometry message
                   moves. Both come from level_bridge, so this catches a frozen TF path/relay, not a frozen LIO.
  T8 map identity  the grid served on <ns>/map must equal the grid this evaluator scores against (size,
                   resolution, origin, occupied cells) and, if expected_map_sha256 is set, the map image hash.
  T2 covariance    AMCL pose covariance: sigma_xy <= sigma_xy_max, sigma_yaw <= sigma_yaw_max.
  T3 particles     weighted particle spread <= cloud_std_max AND weight farther than second_mode_sep from the main
                   mode <= second_mode_weight_max (two competing hypotheses = ambiguous).
  T4 scan vs map   soft endpoint score S (lidar endpoints against the occupied cells of the D1 map, independent of
                   AMCL's belief) >= max(hit_min_abs, hit_baseline_frac * baseline) and no drop > hit_drop_max
                   against the recent median.
  T5 continuity    map->odom step between consecutive ACCEPTED updates (latched per update, not per tick) <= jump_xy_max / jump_yaw_max (relocalization jump).
  T6 anchor        the operator confirmed the pose (floor mark / known start); afterwards
                   |pose_map - anchor (+) LIO displacement| <= anchor_xy_base + anchor_xy_per_m * path_length
                   (and the yaw analogue). LIO odometry does not use the map, so a false global lock or a jump
                   shows up as a disagreement that AMCL's own consistency scores cannot see.
  Arm-time check   ambiguity(): the score landscape around the pose must have no competitor farther than
                   ambiguity_sep from the pose whose score is within ambiguity_margin of the best.
                   While a competitor exists (degenerate scene) the robot may only travel degenerate_budget_m
                   on LIO odometry before trust is withdrawn.

Thresholds are CANDIDATES: they are calibrated from the operator's standing baseline (stage F0 of the test plan),
not approved values.

Two outputs (user architecture decision 2026-10-22, .orchestrator/DECISIONS.md "Simplify Localization Trust"):
  READY      latched. Set at the first evaluation after confirm_anchor() whose GATE checks are clean: T0/T1 fresh
             and valid, T2 covariance, T3 particles, T4 scan score/drop (baseline optional: without it the floor
             is hit_min_abs), T5 no jump, T6 pose still at the confirmed anchor, T8 map identical. Cleared ONLY by
             a jump (T5 in the 1 s window, or the first fresh map->odom after a stale/invalid gap differing from
             the last fresh one by > jump_xy_max / jump_yaw_max), T8 map mismatch/unseen, relocalize() (new initialpose),
             a new confirm_anchor() (re-gated), or critical-input loss (T0/T1) persisting when a new goal is
             requested (goal_request(); transient loss alone does not clear READY).
  MOTION_OK  continuous = READY and no T0/T1 reason (odom, odom message, map->odom TF, scan, frozen TF, AMCL
             freshness via the per-axis "AMCL due" rule only). Published as ~/trusted.
After READY, T2/T3/T4/T6/T7 are DIAGNOSTICS (status 'diagnostics'); they never clear READY or MOTION_OK.
No settling hysteresis: MOTION_OK returns with fresh data, but the coordinator/adapter latch the aborted goal and
the old goal is never resumed; motion again needs operator resume + a NEW goal (arm check on current inputs).
"""
import math
from dataclasses import dataclass, field

import numpy as np



@dataclass
class TrustConfig:
    sigma_xy_max: float = 0.20
    sigma_yaw_max: float = 0.15
    cloud_std_max: float = 0.25
    second_mode_sep: float = 0.50
    second_mode_weight_max: float = 0.10
    score_sigma: float = 0.05            # m, soft-hit width (one map cell)
    rmin: float = 0.5
    rmax: float = 8.0
    hit_min_abs: float = 0.35
    hit_baseline_frac: float = 0.80
    hit_drop_max: float = 0.15
    jump_xy_max: float = 0.10
    jump_yaw_max: float = 0.10
    jump_window_s: float = 1.0   # UNUSED since T5 step semantics (compat only)
    anchor_xy_base: float = 0.15
    anchor_xy_per_m: float = 0.0
    anchor_yaw_base: float = 0.10
    anchor_yaw_per_rad: float = 0.0
    ambiguity_radius: float = 1.0
    ambiguity_step: float = 0.1
    ambiguity_yaw_range: float = 0.5
    ambiguity_yaw_step: float = 0.05
    ambiguity_sep: float = 0.5
    ambiguity_margin: float = 0.05
    # EXPERIMENTAL (not validated on X2): metres of LIO travel allowed after an ambiguous arm check.
    # 0.0 = any ambiguity blocks (conservative default). EXPERIMENTAL_DEGENERATE_BUDGET_M is the 2 m
    # candidate from the task; it must be set explicitly and is reported as experimental in the status.
    degenerate_budget_m: float = 0.0
    # amcl_pose / particle_cloud are only required to be fresh once AMCL was DUE to update: LIO odometry moved
    # >= amcl_update_min_d or rotated >= amcl_update_min_a since the odom pose at the last AMCL output.
    # pose_max_age_moving_s is the maximum AMCL lag (scan latency + filter time, measured 0.36-2.0 s under load)
    # between "due" and the new output. COUPLING: amcl_update_min_d / amcl_update_min_a MUST equal the AMCL
    # update_min_d / update_min_a actually running. localization.launch.py does not override them, so they are
    # the nav2_amcl humble defaults (nav2_amcl/src/amcl_node.cpp:201,205 of navigation2 1.1.18: 0.2 rad, 0.25 m).
    # If either side changes, change both. Standing AMCL is silent by design (no odom displacement, no output).
    pose_max_age_moving_s: float = 3.0
    amcl_update_min_d: float = 0.25
    amcl_update_min_a: float = 0.2
    tf_max_age_s: float = 1.0
    scan_max_age_s: float = 0.5
    odom_max_age_s: float = 0.5
    stable_s: float = 5.0                # UNUSED since 2026-10-22 (no settling hysteresis); kept for parameter compatibility
    # EXPERIMENTAL frozen-TF detector: window and minimum odometry-message motion inside it. 1 s is five
    # trust evaluations; 0.05 m / 0.05 rad is one map cell / the T5 yaw scale and ~1/6 s at the 0.3 m/s
    # Nav2 limit, far above the bit-identical criterion used for the TF side. Not calibrated on X2.
    frozen_window_s: float = 1.0
    frozen_motion_min_m: float = 0.05
    frozen_motion_min_rad: float = 0.05
    require_map_match: bool = True


EXPERIMENTAL_DEGENERATE_BUDGET_M = 2.0


def map_identity(grid, resolution, origin_xy, width, height, data, occupied_value=100):
    """'' when the served OccupancyGrid equals `grid` (map_server trinary: occupied = 100), else a reason."""
    if abs(float(resolution) - grid.res) > 1e-9:
        return 'resolution'
    if abs(float(origin_xy[0]) - grid.ox) > 1e-6 or abs(float(origin_xy[1]) - grid.oy) > 1e-6:
        return 'origin'
    if (int(height), int(width)) != (grid.h, grid.w):
        return 'size'
    occ = np.asarray(data, dtype=np.int16).reshape(grid.h, grid.w) == occupied_value
    if not np.array_equal(occ, grid.occ):
        return 'occupied_cells'
    return ''


def wrap(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


# ------------------------------------------------------------------ small measurements
def pose_sigmas(cov36):
    """sigma_xy (sqrt of the larger xy eigenvalue) and sigma_yaw from a row-major 6x6 covariance."""
    c = np.asarray(cov36, float).reshape(6, 6)
    if not np.isfinite(c).all() or not np.allclose(c,c.T) or c[5,5] < 0:
        return float('inf'),float('inf')
    ev = np.linalg.eigvalsh(c[:2, :2])
    if ev[0] < 0:return float('inf'),float('inf')
    return math.sqrt(max(ev[-1], 0.0)), math.sqrt(max(c[5, 5], 0.0))


def cloud_stats(xy, w, sep):
    """(weighted spread, weight outside `sep` of the heaviest particle). Weights need not be normalized."""
    xy, w = np.asarray(xy, float).reshape(-1, 2), np.asarray(w, float)
    if (len(xy) == 0 or len(w) != len(xy) or not np.isfinite(xy).all() or
        not np.isfinite(w).all() or (w < 0).any() or w.sum() <= 0):
        return float('inf'), 1.0
    w = w / w.sum()
    mode = xy[int(np.argmax(w))]
    near = np.hypot(*(xy - mode).T) <= sep
    outside = float(w[~near].sum())
    m = (xy[near] * w[near, None]).sum(0) / max(w[near].sum(), 1e-12)
    d2 = ((xy[near] - m) ** 2).sum(1)
    spread = math.sqrt(float((d2 * w[near]).sum() / max(w[near].sum(), 1e-12)))
    return spread, outside


class OccGrid:
    """Distance (m) to the nearest occupied cell of a Nav2 map; unknown cells are NOT obstacles."""

    def __init__(self, occupied, resolution, origin_xy):
        from scipy.ndimage import distance_transform_edt
        self.res, self.ox, self.oy = float(resolution), float(origin_xy[0]), float(origin_xy[1])
        occ = np.asarray(occupied, bool)
        self.occ = occ
        self.h, self.w = occ.shape
        self.dist = distance_transform_edt(~occ) * self.res if occ.any() else np.full(occ.shape, np.inf)

    @classmethod
    def from_pgm(cls, yaml_path):
        import os

        import cv2
        import yaml
        with open(yaml_path) as f:
            y = yaml.safe_load(f)
        img = cv2.imread(os.path.join(os.path.dirname(yaml_path), y['image']), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise FileNotFoundError(y['image'])
        p = img / 255.0 if y.get('negate', 0) else (255 - img) / 255.0     # occupancy probability
        img = np.flipud(p)                                                   # row 0 = bottom (y up)
        return cls(img > float(y.get('occupied_thresh', 0.65)), y['resolution'], y['origin'][:2])

    def dist_at(self, pts):
        i = np.floor((pts[:, 1] - self.oy) / self.res).astype(int)
        j = np.floor((pts[:, 0] - self.ox) / self.res).astype(int)
        ok = (i >= 0) & (i < self.h) & (j >= 0) & (j < self.w)
        d = np.full(len(pts), np.inf)
        d[ok] = self.dist[i[ok], j[ok]]
        return d


def scan_endpoints(ranges, angle_min, angle_inc, rmin, rmax):
    """Endpoints in the sensor (base_footprint) frame."""
    r = np.asarray(ranges, float)
    a = angle_min + angle_inc * np.arange(len(r))
    ok = np.isfinite(r) & (r >= rmin) & (r <= rmax)
    return np.column_stack((r[ok] * np.cos(a[ok]), r[ok] * np.sin(a[ok])))


def to_map(pts_base, pose):
    x, y, th = pose
    c, s = math.cos(th), math.sin(th)
    return np.column_stack((x + c * pts_base[:, 0] - s * pts_base[:, 1], y + s * pts_base[:, 0] + c * pts_base[:, 1]))


def soft_score(pts_base, grid, pose, sigma):
    """Mean exp(-d^2 / 2 sigma^2) over endpoints (1 = all on occupied cells); 0 without points."""
    if len(pts_base) == 0:
        return 0.0
    d = grid.dist_at(to_map(pts_base, pose))
    return float(np.mean(np.exp(-np.minimum(d, 10.0) ** 2 / (2 * sigma ** 2))))


def ambiguity(pts_base, grid, pose, cfg: TrustConfig):
    """Score landscape around `pose`. Returns dict(nominal, best, competitor_score, competitor_offset, ambiguous).
    A competitor is a pose farther than ambiguity_sep (xy) from `pose` whose score is within ambiguity_margin of
    max(nominal, best)."""
    x0, y0, th0 = pose
    r, st = cfg.ambiguity_radius, cfg.ambiguity_step
    xs = np.arange(-r, r + 1e-9, st)
    ths = np.arange(-cfg.ambiguity_yaw_range, cfg.ambiguity_yaw_range + 1e-9, cfg.ambiguity_yaw_step)
    nominal = soft_score(pts_base, grid, pose, cfg.score_sigma)
    best = (nominal, (0.0, 0.0, 0.0))
    comp = (-1.0, None)
    for dth in ths:
        for dx in xs:
            for dy in xs:
                s = soft_score(pts_base, grid, (x0 + dx, y0 + dy, th0 + dth), cfg.score_sigma)
                if s > best[0]:
                    best = (s, (dx, dy, dth))
                if math.hypot(dx, dy) > cfg.ambiguity_sep and s > comp[0]:
                    comp = (s, (dx, dy, dth))
    top = max(nominal, best[0])
    return dict(nominal=nominal, best=best[0], best_offset=best[1], competitor_score=comp[0],
                competitor_offset=comp[1], ambiguous=bool(comp[1] is not None and comp[0] >= top - cfg.ambiguity_margin))


def compose(a, b):
    """a (+) b for SE(2) tuples (x, y, yaw)."""
    c, s = math.cos(a[2]), math.sin(a[2])
    return (a[0] + c * b[0] - s * b[1], a[1] + s * b[0] + c * b[1], wrap(a[2] + b[2]))


def inverse(a):
    c, s = math.cos(a[2]), math.sin(a[2])
    return (-(c * a[0] + s * a[1]), s * a[0] - c * a[1], wrap(-a[2]))


# ------------------------------------------------------------------ stateful evaluator
@dataclass
class Inputs:
    now: float
    map_odom: tuple = None              # (x, y, yaw) of map->odom
    map_odom_stamp: float = float('-inf')
    odom_base: tuple = None             # (x, y, yaw) of odom->base_footprint (LIO)
    odom_stamp: float = float('-inf')
    odom_msg_stamp: float = float('-inf')
    amcl_cov: list = None
    amcl_stamp: float = float('-inf')
    cloud_xy: object = None
    cloud_w: object = None
    cloud_stamp: float = float('-inf')
    odom_msg_pose: tuple = None         # (x, y, yaw) of the odometry message (frozen-TF cross-check)
    map_ok: object = None               # None = served map not seen yet, '' = identical, else mismatch reason
    odom_at_scan: tuple = None          # odom->base_footprint at the scan's source stamp (T4); None = odom_base
    scan_pts: object = None             # endpoints in base_footprint
    scan_stamp: float = float('-inf')
    moving: bool = False                # status only (noisy on a standing humanoid); no longer gates T1 freshness
    odom_at_amcl: tuple = None          # odom->base_footprint at the amcl_pose source stamp (None = cannot judge, not due)
    odom_at_cloud: tuple = None         # odom->base_footprint when the particle_cloud was received


class TrustEvaluator:
    def __init__(self, grid: OccGrid, cfg: TrustConfig = None):
        self.grid, self.cfg = grid, cfg or TrustConfig()
        self.baseline = None
        self.scores = []                 # (t, S)
        self.mo_prev = None              # last ACCEPTED map->odom (observe_map_odom), per-update T5 reference
        self.step_latch = None           # (max step xy, max step yaw) seen since the last evaluation, only if violating
        self.step_max = (0.0, 0.0)       # max step since the last evaluation (metrics)
        self.mo_ref, self.mo_gap = None, False   # last map->odom of a fresh valid tick; a stale/invalid tick since
        self.anchor = None               # (map_pose, odom_pose, path_len_at_anchor)
        self.path_len, self._last_odom = 0.0, None
        self.degenerate_since_len = None
        self.frz = []                    # (t, odom_base TF, odom message pose)
        self._due = {}                   # 'pose'/'cloud' -> (output stamp, time AMCL became due or None)
        self.ready, self.pending, self.ready_cause = False, False, 'no_anchor'
        self.last = dict(trusted=False, ready=False, motion_ok=False, reasons=['no_data'], diagnostics=[], metrics={})

    def observe_map_odom(self, value):
        """Per-update T5: call for EVERY accepted map->odom value (TF callback; the node holds its lock). Compares with the
        previous accepted value; a step > jump_xy_max / jump_yaw_max is LATCHED until the next evaluate() consumes it, so a
        0 -> 0.5 -> 0 sequence between two ticks is not lost. Identical values (republish) = step 0. Non-finite values are
        ignored here (evaluate() reports T0_invalid_pose from the tick input)."""
        if value is None or len(value) != 3 or not np.isfinite(value).all():
            return
        v = tuple(value)
        prev, self.mo_prev = self.mo_prev, v
        if prev is None:
            return
        jx, jy = math.hypot(v[0] - prev[0], v[1] - prev[1]), abs(wrap(v[2] - prev[2]))
        self.step_max = (max(self.step_max[0], jx), max(self.step_max[1], jy))
        if jx > self.cfg.jump_xy_max or jy > self.cfg.jump_yaw_max:
            l = self.step_latch or (0.0, 0.0)
            self.step_latch = (max(l[0], jx), max(l[1], jy))

    # -- operator actions
    def set_baseline(self, scores):
        """Median score from a clean standing recording at a confirmed pose (stage F0)."""
        self.baseline = float(np.median(scores))

    def confirm_anchor(self, inp: Inputs):
        """Operator confirmed the pose. READY is (re)gated at the next evaluation; until then it is false."""
        pose = compose(inp.map_odom, inp.odom_base)
        self.anchor = (pose, inp.odom_base, self.path_len)
        self.ready, self.pending, self.ready_cause = False, True, 'pending_gate'
        return pose

    def relocalize(self):
        """Operator sent a new initial pose: the old anchor and READY no longer apply until confirm_anchor()."""
        self.anchor, self.ready, self.pending, self.ready_cause = None, False, False, 'initialpose'

    def goal_request(self):
        """A new goal is requested. Critical-input loss (T0/T1) still present now is 'prolonged': READY is lost.
        Returns the motion-blocking reasons of the latest evaluation ([] = MOTION_OK if READY)."""
        loss = [r for r in self.last.get('reasons', []) if r.startswith(('T0', 'T1'))]
        if self.ready and loss:
            self.ready, self.ready_cause = False, 'input_loss_at_goal_request:' + ','.join(loss)
            self.last = dict(self.last, trusted=False, ready=False, motion_ok=False,
                             reasons=loss + ['not_ready:' + self.ready_cause])
        return loss

    def arm_check(self, inp: Inputs):
        """Run before enabling motion for a goal (from standing). Returns the ambiguity dict. Since 2026-10-22 an
        ambiguous result only starts the T7 DIAGNOSTIC (degenerate budget); it does not refuse the goal."""
        pose = compose(inp.map_odom, inp.odom_base)
        a = ambiguity(inp.scan_pts, self.grid, pose, self.cfg)
        self.degenerate_since_len = self.path_len if a['ambiguous'] else None
        return a

    def _amcl_overdue(self, key, stamp, odom_at, inp):
        """True when AMCL has been due to update (odom moved >= min_d / min_a since `odom_at`) for longer than
        pose_max_age_moving_s. A new output stamp resets the due timer."""
        c = self.cfg
        if self._due.get(key, (None, None))[0] != stamp:
            self._due[key] = (stamp, None)
        if odom_at is None or inp.odom_base is None:
            return False
        # nav2_amcl 1.1.18 amcl_node.cpp:775-777 shouldUpdateFilter: per-axis, strict '>', deltas of the base pose
        # in the odom frame (not rotated, not Euclidean): |dx|>d || |dy|>d || |angle_diff|>a.
        due = (abs(inp.odom_base[0] - odom_at[0]) > c.amcl_update_min_d or
               abs(inp.odom_base[1] - odom_at[1]) > c.amcl_update_min_d or
               abs(wrap(inp.odom_base[2] - odom_at[2])) > c.amcl_update_min_a)
        since = self._due[key][1]
        if not due:
            self._due[key] = (stamp, None)
            return False
        if since is None:
            since = inp.now
            self._due[key] = (stamp, since)
        return inp.now - since > c.pose_max_age_moving_s

    # -- one evaluation (call at ~5 Hz)
    def evaluate(self, inp: Inputs):
        c, why, m = self.cfg, [], {}
        for value in (inp.map_odom, inp.odom_base):
            if value is not None and (len(value)!=3 or not np.isfinite(value).all()):
                self.mo_gap = True       # keep mo_ref: the first fresh value after the gap is compared with it
                return self._verdict(['T0_invalid_pose'], {})
        if inp.scan_pts is not None and not np.isfinite(inp.scan_pts).all():
            self.mo_gap = True
            return self._verdict(['T0_invalid_scan'], {})
        if self._last_odom is not None and inp.odom_base is not None:
            self.path_len += math.hypot(inp.odom_base[0] - self._last_odom[0], inp.odom_base[1] - self._last_odom[1])
        if inp.odom_base is not None:
            self._last_odom = inp.odom_base
        # T1: reception and source stamps must both be validated by the ROS wrapper.
        if inp.odom_base is None or not 0 <= inp.now - inp.odom_stamp <= c.odom_max_age_s:
            why.append('T1_odom_stale')
        if not 0 <= inp.now - inp.odom_msg_stamp <= c.odom_max_age_s:
            why.append('T1_odom_message_stale')
        if inp.map_odom is None or inp.now - inp.map_odom_stamp > c.tf_max_age_s:
            why.append('T1_tf_stale')
        if inp.amcl_cov is None or self._amcl_overdue('pose', inp.amcl_stamp, inp.odom_at_amcl, inp):
            why.append('T1_amcl_pose_stale')
        if inp.cloud_xy is not None and self._amcl_overdue('cloud', inp.cloud_stamp, inp.odom_at_cloud, inp):
            why.append('T1_particle_cloud_stale')
        if inp.scan_pts is None or inp.now - inp.scan_stamp > c.scan_max_age_s:
            why.append('T1_scan_stale')
        if inp.odom_base is not None and inp.odom_msg_pose is not None:
            self.frz = [x for x in self.frz if inp.now - x[0] <= c.frozen_window_s] + [(inp.now, tuple(inp.odom_base), tuple(inp.odom_msg_pose))]
            t0, tf0, msg0 = self.frz[0]
            # the window must be covered by >= 4 of the 5 evaluation periods (5 Hz) before judging
            if inp.now - t0 >= 0.8 * c.frozen_window_s and all(x[1] == tf0 for x in self.frz):
                moved = max(math.hypot(x[2][0] - msg0[0], x[2][1] - msg0[1]) for x in self.frz)
                turned = max(abs(wrap(x[2][2] - msg0[2])) for x in self.frz)
                m.update(frozen_msg_motion_m=moved)
                if moved > c.frozen_motion_min_m or turned > c.frozen_motion_min_rad:
                    why.append('T1_tf_frozen')
        # T8
        if c.require_map_match:
            if inp.map_ok is None:
                why.append('T8_map_unseen')
            elif inp.map_ok:
                why.append('T8_map_mismatch')
        # T2
        if inp.amcl_cov is not None:
            sxy, syaw = pose_sigmas(inp.amcl_cov)
            m.update(sigma_xy=sxy, sigma_yaw=syaw)
            if not (sxy <= c.sigma_xy_max and syaw <= c.sigma_yaw_max):
                why.append('T2_covariance')
        # T3
        if inp.cloud_xy is not None:
            spread, outside = cloud_stats(inp.cloud_xy, inp.cloud_w, c.second_mode_sep)
            m.update(cloud_std=spread, second_mode_weight=outside)
            if not (spread <= c.cloud_std_max and outside <= c.second_mode_weight_max):
                why.append('T3_particles')
        else:
            why.append('T3_no_particles')
        # Candidate baseline must be explicitly collected before autonomous trust.
        if self.baseline is None:
            why.append('T4_no_baseline')
        if inp.scan_pts is not None and len(inp.scan_pts)==0:
            why.append('T4_empty_scan')
        # T4
        if inp.map_odom is not None and inp.odom_base is not None and inp.scan_pts is not None and len(inp.scan_pts):
            # Score the scan at the pose it was taken from: while turning at 0.5 rad/s a 0.1 s lag moves
            # endpoints at 3 m by 0.15 m (3 score sigmas).
            pose = compose(inp.map_odom, inp.odom_at_scan if inp.odom_at_scan is not None else inp.odom_base)
            s = soft_score(inp.scan_pts, self.grid, pose, c.score_sigma)
            m['scan_score'] = s
            self.scores = [(t, v) for t, v in self.scores if inp.now - t <= 5.0] + [(inp.now, s)]
            floor = max(c.hit_min_abs, c.hit_baseline_frac * self.baseline) if self.baseline else c.hit_min_abs
            m['scan_floor'] = floor
            if s < floor:
                why.append('T4_scan_score')
            recent = [v for _, v in self.scores]
            if len(recent) >= 5 and np.median(recent) - s > c.hit_drop_max:
                why.append('T4_scan_drop')
        # T5 across a gap: the 1 s window forgets a jump that happened while map->odom was stale/invalid; compare the
        # first fresh value after any gap with the last fresh valid one (same jump_xy_max / jump_yaw_max).
        if 'T1_tf_stale' in why:
            self.mo_gap = True
        else:
            if self.mo_gap and self.mo_ref is not None:
                gx = math.hypot(inp.map_odom[0] - self.mo_ref[0], inp.map_odom[1] - self.mo_ref[1])
                gy = abs(wrap(inp.map_odom[2] - self.mo_ref[2]))
                m.update(gap_jump_xy=gx, gap_jump_yaw=gy)
                if gx > c.jump_xy_max or gy > c.jump_yaw_max:
                    why.append('T5_map_odom_jump_across_gap')
            self.mo_ref, self.mo_gap = tuple(inp.map_odom), False
        # T5: step between CONSECUTIVE valid map->odom samples (each AMCL update) > jump_xy_max / jump_yaw_max.
        # Was: accumulated change within jump_window_s. Evidence (ONE session, provisional; bag short_nav_01, return turn
        # 1792667921-928): AMCL per-update corrections 0.02-0.07 m (max 0.066), yaw +-1-2 deg, monotonic; the cumulative
        # 0.12 m in 1.7 s tripped the window rule and latched the adapter mid-turn. False global locks are >= 0.5 m / 0.3 rad.
        # jump_window_s is now unused (kept for config compatibility). After a stale/NaN gap the previous sample is the
        # last fresh one, so the first fresh sample is compared with it (same rule; see gap block above).
        # The tick value is also fed to observe_map_odom (no-op when the node already saw it: same value = step 0).
        if inp.map_odom is not None:
            self.observe_map_odom(inp.map_odom)
        latch, (sx, sy) = self.step_latch, self.step_max
        self.step_latch, self.step_max = None, (0.0, 0.0)
        m.update(jump_xy=sx, jump_yaw=sy)
        if latch is not None:
            m.update(jump_latched_xy=latch[0], jump_latched_yaw=latch[1])
            if 'T5_map_odom_jump_across_gap' not in why:
                why.append('T5_map_odom_jump')   # across a gap the gap reason already reports it
        # T6
        if self.anchor is None:
            why.append('T6_no_anchor')
        elif inp.map_odom is not None and inp.odom_base is not None:
            a_map, a_odom, a_len = self.anchor
            predicted = compose(a_map, compose(inverse(a_odom), inp.odom_base))
            now_pose = compose(inp.map_odom, inp.odom_base)
            dist = self.path_len - a_len
            ex = math.hypot(now_pose[0] - predicted[0], now_pose[1] - predicted[1])
            ey = abs(wrap(now_pose[2] - predicted[2]))
            lim_x = c.anchor_xy_base + c.anchor_xy_per_m * dist
            lim_y = c.anchor_yaw_base + c.anchor_yaw_per_rad * dist
            m.update(anchor_err_xy=ex, anchor_err_yaw=ey, anchor_limit_xy=lim_x, path_since_anchor=dist)
            if ex > lim_x or ey > lim_y:
                why.append('T6_anchor_disagreement')
        # degenerate budget
        if self.degenerate_since_len is not None:
            used = self.path_len - self.degenerate_since_len
            m['degenerate_used_m'] = used
            if c.degenerate_budget_m <= 0:
                why.append('T7_ambiguous')
            elif used > c.degenerate_budget_m:
                why.append('T7_degenerate_budget')
        return self._verdict(why, m)

    # -- READY / MOTION_OK from the raw check results (see module docstring)
    GATE_SKIP = ('T4_no_baseline', 'T6_no_anchor', 'T7_')    # not part of the READY gate

    def _verdict(self, why, m):
        motion = [r for r in why if r.startswith(('T0', 'T1'))]
        diag = [r for r in why if r.startswith(('T2', 'T3', 'T4', 'T6', 'T7'))]
        clear = [r for r in why if r.startswith(('T8', 'T5'))]
        gate = []
        if self.ready and clear:
            self.ready, self.ready_cause = False, ','.join(clear)
        elif self.pending:
            gate = [r for r in why if not r.startswith(self.GATE_SKIP)]
            if not gate:
                self.ready, self.pending, self.ready_cause = True, False, ''
        motion_ok = self.ready and not motion
        reasons = motion + ([] if self.ready else ['not_ready:' + self.ready_cause] + [r for r in gate if r not in motion])
        self.last = dict(trusted=motion_ok, ready=self.ready, motion_ok=motion_ok, reasons=reasons,
                         diagnostics=diag, metrics=m)
        return self.last
